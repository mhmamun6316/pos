<?php $__env->startSection('css'); ?>
<style>
    #name-error
    {
        color:red ;
    }
    .buttons button{
        margin-bottom: 4px;
    }
    .bg-primary th{
        color: white!important;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

<section id="basic-datatable">
    <div class="row">
        <h1>All Expenses</small>
        </h1>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="card p-2 card-top">
          <table id="example" class="table table-striped table-bordered" style="width:100%">
              <thead class="text-center">
                <tr>
                    <th scope="col">SL</th>
                    <th>Outlet</th>
                    <th>Expense Category</th>
                    <th>Name</th>
                    <th>Amount</th>
                    <th>Actions</th>
                  </tr>
              </thead>
              <?php
                  $sl=1;
              ?>
              <tbody id="tableBody" class="text-center">
                  <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                     <td><?php echo e($sl++); ?></td>
                     <td><?php echo e($expense->outlet->name); ?></td>
                     <td><?php echo e($expense->category->name); ?></td>
                     <td><?php echo e($expense->name); ?></td>
                     <td><?php echo e($expense->amount); ?></td>
                     <td>
                        <button class="btn btn-sm btn-danger deleteBtn" value="<?php echo e($expense->id); ?>"><i class="fas fa-trash"></i></button>
                     </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
          </table>
        </div>
      </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
    $(document).ready(function(){
        $('#example').DataTable({
            scrollX: true,
            "pageLength": 10
        });
    });

    //deleting data
    $(document).on('click', '.deleteBtn', function() {
        var id = $(this).val();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: "DELETE",
            url: "/expenses/" + id ,
            contentType: false,
            processData: false,
            success: function(response) {
                toastr.error(response.message);
                location.reload();
            }
        });
    });

</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\Pos\resources\views/expense/all_expense.blade.php ENDPATH**/ ?>