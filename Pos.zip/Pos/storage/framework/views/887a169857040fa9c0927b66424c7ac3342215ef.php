<?php $__env->startSection('css'); ?>
<style>
    .error
    {
        color:red!important ;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

<h1 class="header-title">
    <strong>Top Products Report</strong>
</h1>

<div class="row">

    <div class="col-12">
        <div class="card">
             <div class="card-body">
                <table class="example table table-striped table-bordered" style="width:100%">
                    <thead class="text-center">
                      <tr>
                          <th>Product Name</th>
                          <th>Code</th>
                          <th>Sold Quantity</th>
                        </tr>
                    </thead>
                    <tbody id="tableBody" class="text-center">
                        <?php $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->sku); ?></td>
                                <td><?php echo e($item->count); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
             </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\Pos\resources\views/reports/top_products_report.blade.php ENDPATH**/ ?>