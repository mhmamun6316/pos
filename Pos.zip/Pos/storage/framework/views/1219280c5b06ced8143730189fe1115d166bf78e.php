<?php $__env->startSection('css'); ?>
    <style>
        .card{
            height: 100%!important;
        }

        .text-yellow{
            color: yellow;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
    
    <div class="row">
        <div class="col-lg-3 col-sm-6 col-12 mb-2">
          <div class="card">
            <div class="card-header" >
              <div>
                <h2 class="fw-bolder mb-0">৳ <?php echo e($today_sell); ?></h2>
                <p class="card-text">Sold In Today</p>
              </div>
              <div class="avatar bg-light-primary p-50 m-0">
                <div class="avatar-content">
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-cpu font-medium-5"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="14" x2="23" y2="14"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="14" x2="4" y2="14"></line></svg>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-sm-6 col-12 mb-2">
          <div class="card">
            <div class="card-header">
              <div>
                <h2 class="fw-bolder mb-0">৳ <?php echo e(empty($today_gross_profit->sums) ? 0 : $today_gross_profit->sums); ?></h2>
                <p class="card-text">Purchase In Today</p>
              </div>
              <div class="avatar bg-light-success p-50 m-0">
                <div class="avatar-content">
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-server font-medium-5"><rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect><rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect><line x1="6" y1="6" x2="6.01" y2="6"></line><line x1="6" y1="18" x2="6.01" y2="18"></line></svg>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-3 col-sm-6 col-12 mb-2">
          <div class="card">
            <div class="card-header">
              <div>
                <h2 class="fw-bolder mb-0">৳ <?php echo e($today_expenses); ?></h2>
                <p class="card-text">Expense In Today</p>
              </div>
              <div class="avatar bg-light-danger p-50 m-0">
                <div class="avatar-content">
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-activity font-medium-5"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-sm-6 col-12 mb-2">
          <div class="card">
            <div class="card-header">
              <div>
                <h2 class="fw-bolder mb-0">৳ <?php echo e($today_net_profit); ?></h2>
                <p class="card-text">Profit In Today</p>
              </div>
              <div class="avatar bg-light-warning p-50 m-0">
                <div class="avatar-content">
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-alert-octagon font-medium-5"><polygon points="7.86 2 16.14 2 22 7.86 22 16.14 16.14 22 7.86 22 2 16.14 2 7.86 7.86 2"></polygon><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>

    
    <div class="row">
        <div class="col-lg-3 col-sm-6 col-12 mb-2">
          <div class="card">
            <div class="card-header" >
              <div>
                <h2 class="fw-bolder mb-0">৳ <?php echo e((int)$monthly_sell); ?></h2>
                <p class="card-text">Sold In <?php echo e($current_month_name); ?></p>
              </div>
              <div class="avatar bg-light-primary p-50 m-0">
                <div class="avatar-content">
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-cpu font-medium-5"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="14" x2="23" y2="14"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="14" x2="4" y2="14"></line></svg>
                </div>
              </div>
            </div>
          </div>
        </div>
         <div class="col-lg-3 col-sm-6 col-12 mb-2">
          <div class="card">
            <div class="card-header">
              <div>
                <h2 class="fw-bolder mb-0">৳ <?php echo e(empty($monthly_gross_profit->sums) ? 0 : $monthly_gross_profit->sums); ?> </h2>
                <p class="card-text">Purchase In <?php echo e($current_month_name); ?></p>
              </div>
              <div class="avatar bg-light-success p-50 m-0">
                <div class="avatar-content">
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-server font-medium-5"><rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect><rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect><line x1="6" y1="6" x2="6.01" y2="6"></line><line x1="6" y1="18" x2="6.01" y2="18"></line></svg>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-3 col-sm-6 col-12 mb-2">
          <div class="card">
            <div class="card-header">
              <div>
                <h2 class="fw-bolder mb-0">৳ <?php echo e($monthly_expenses); ?></h2>
                <p class="card-text">Expense In <?php echo e($current_month_name); ?></p>
              </div>
              <div class="avatar bg-light-danger p-50 m-0">
                <div class="avatar-content">
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-activity font-medium-5"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-sm-6 col-12 mb-2">
          <div class="card">
            <div class="card-header">
              <div>
                <h2 class="fw-bolder mb-0">৳ <?php echo e($monthly_net_profit); ?></h2>
                <p class="card-text">Profit In <?php echo e($current_month_name); ?></p>
              </div>
              <div class="avatar bg-light-warning p-50 m-0">
                <div class="avatar-content">
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-alert-octagon font-medium-5"><polygon points="7.86 2 16.14 2 22 7.86 22 16.14 16.14 22 7.86 22 2 16.14 2 7.86 7.86 2"></polygon><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>

    
    <div class="row">
        <div class="col-lg-3 col-sm-6 col-12 mb-2">
          <div class="card">
            <div class="card-header" >
              <div>
                <h2 class="fw-bolder mb-0">৳ <?php echo e((int)$yearly_sell); ?></h2>
                <p class="card-text">Sold In <?php echo e($current_year); ?></p>
              </div>
              <div class="avatar bg-light-primary p-50 m-0">
                <div class="avatar-content">
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-cpu font-medium-5"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="14" x2="23" y2="14"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="14" x2="4" y2="14"></line></svg>
                </div>
              </div>
            </div>
          </div>
        </div>
         <div class="col-lg-3 col-sm-6 col-12 mb-2">
          <div class="card">
            <div class="card-header">
              <div>
                <h2 class="fw-bolder mb-0">৳ <?php echo e(empty($yearly_gross_profit->sums) ? 0 : $yearly_gross_profit->sums); ?></h2>
                <p class="card-text">Purchase In <?php echo e($current_year); ?></p>
              </div>
              <div class="avatar bg-light-success p-50 m-0">
                <div class="avatar-content">
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-server font-medium-5"><rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect><rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect><line x1="6" y1="6" x2="6.01" y2="6"></line><line x1="6" y1="18" x2="6.01" y2="18"></line></svg>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-3 col-sm-6 col-12 mb-2">
          <div class="card">
            <div class="card-header">
              <div>
                <h2 class="fw-bolder mb-0">৳ <?php echo e($yearly_expenses); ?></h2>
                <p class="card-text">Expenses In <?php echo e($current_year); ?></p>
              </div>
              <div class="avatar bg-light-danger p-50 m-0">
                <div class="avatar-content">
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-activity font-medium-5"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-sm-6 col-12 mb-2">
          <div class="card">
            <div class="card-header">
              <div>
                <h2 class="fw-bolder mb-0">৳ <?php echo e($yearly_net_profit); ?></h2>
                <p class="card-text">Profit In <?php echo e($current_year); ?></p>
              </div>
              <div class="avatar bg-light-warning p-50 m-0">
                <div class="avatar-content">
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-alert-octagon font-medium-5"><polygon points="7.86 2 16.14 2 22 7.86 22 16.14 16.14 22 7.86 22 2 16.14 2 7.86 7.86 2"></polygon><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>

     
     <section id="basic-datatable">
        <div class="row">
          <div class="col-12">
            <div class="card p-2 card-top">
              <div class="d-flex justify-content-between mb-1">
                  <h4><i class="fa fa-exclamation-triangle text-yellow" aria-hidden="true"></i> Product Stock Available </h4>
              </div>
              <table class="example table table-striped table-bordered" style="width:100%">
                <thead class="text-center">
                  <tr>
                      <th scope="col">Product</th>
                      <th scope="col">Location</th>
                      <th scope="col">Unit Price</th>
                      <th scope="col">Current Stock</th>
                      <th scope="col">Current Stock Value <br> <small>(By purchase price)</small></th>
                      <th scope="col">Current Stock Value <br> <small>(By sale price)</small></th>
                      <th scope="col">Potential profit</th>
                      
                    </tr>
                </thead>
                <tbody id="tableBody" class="text-center">
                    <?php
                        $total_quantity = 0;
                        $total_by_purchase = 0;
                        $total_by_sell = 0;
                    ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $sell = $product->quantity * $product->selling_price;
                        $purchase = $product->quantity * $product->inc_purchase_price;
                        $total_quantity +=  $product->quantity;
                        $total_by_purchase += $purchase;
                        $total_by_sell += $sell;
                    ?>
                      <tr>
                          <td><?php echo e($product->name); ?></td>
                          <td><?php echo e(optional($product->outlet)->name); ?></td>
                          <td><?php echo e($product->selling_price); ?>TK</td>
                          <td><?php echo e($product->quantity); ?>PC</td>
                          <td><?php echo e($purchase); ?>TK</td>
                          <td><?php echo e($sell); ?>TK</td>
                          <td><?php echo e($sell - $purchase); ?>TK</td>
                          
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot class="text-center">
                      <tr>
                         <td colspan="3"><b>Total:</b></td>
                         <td><b><?php echo e($total_quantity); ?>PC</b></td>
                         <td><b><?php echo e($total_by_purchase); ?>TK</b></td>
                         <td><b><?php echo e($total_by_sell); ?>TK</b></td>
                         <td><b><?php echo e($total_by_sell - $total_by_purchase); ?>TK</b></td>
                         
                      </tr>
                </tfoot>
            </table>
            </div>
          </div>
        </div>
    </section> <br> <br>

    
    <section id="basic-datatable">
        <div class="row">
          <div class="col-12">
            <div class="card p-2 card-top">
              <div class="d-flex justify-content-between mb-1">
                  <h4><i class="fa fa-exclamation-triangle text-yellow" aria-hidden="true"></i> Product Stock Alert <i class="fa fa-info-circle text-info hover-q no-print" data-bs-toggle="popover" data-bs-content="Products with low stock.Based on product alert quantity set in add product screen.Purchase this products before stock ends" data-bs-placement="bottom" data-bs-trigger="hover"></i></h4>
              </div>
              <table class="example table table-striped table-bordered" style="width:100%">
                  <thead class="text-center">
                    <tr>
                        <th scope="col">Name</th>
                        <th scope="col">Location</th>
                        <th scope="col">Current Stock</th>
                      </tr>
                  </thead>
                  <tbody id="tableBody" class="text-center">
                    <?php $__currentLoopData = $alerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($alert->name); ?></td>
                            <td><?php echo e($alert->outlet->name); ?></td>
                            <td><?php echo e($alert->quantity); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
              </table>
            </div>
          </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
    $(document).ready(function(){
        $('.example').DataTable({
            scrollX: true,
            "pageLength": 10
        });
    });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\Pos\resources\views/index.blade.php ENDPATH**/ ?>