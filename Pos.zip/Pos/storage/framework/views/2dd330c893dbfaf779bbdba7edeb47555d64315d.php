<?php $__env->startSection('css'); ?>
<style>
    #name-error
    {
        color:red ;
    }
    .bg-primary th{
        color: white!important;
    }
    .form-group{
        margin-bottom: 5px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

<section id="basic-datatable">
    <div class="row">
      <div class="col-12">
        <div class="card p-2 card-top">
          <table id="example" class="table table-striped table-bordered" style="width:100%">
              <thead class="text-center">
                <tr>
                    <th scope="col">SL</th>
                    <th>Invoice</th>
                    <th>Outlet</th>
                    <th>Customer</th>
                    <th>Status</th>
                    <th>Total</th>
                    <th>Due Amount</th>
                    <th>Last Payment</th>
                    <th>Actions</th>
                  </tr>
              </thead>
              <?php
                  $sl=1;
              ?>
              <tbody id="tableBody" class="text-center">
                  <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
                      $n = count($sale->dueSale);
                  ?>
                  <tr>
                     <td><?php echo e($sl++); ?></td>
                     <td><?php echo e($sale->invoice_no); ?></td>
                     <td><?php echo e($sale->outlet->name); ?></td>
                     <td><?php echo e($sale->customer->name); ?></td>
                     <td>
                        <?php if($sale->status == "Paid"): ?>
                            <span class="badge bg-primary"><?php echo e($sale->status); ?></span>
                        <?php else: ?>
                            <span class="badge bg-danger"><?php echo e($sale->status); ?></span>
                        <?php endif; ?>
                     </td>
                     <td><?php echo e($sale->total); ?></td>
                     <td><?php echo e($sale->due_amount); ?></td>
                     <td>
                        <?php if($n >= 1): ?>
                          <?php echo e($sale->dueSale[$n-1]->payment_dat); ?>

                        <?php else: ?>
                          <?php echo e($sale->created_at->format('Y-m-d')); ?>

                        <?php endif; ?>
                     </td>
                     <td>
                        <button class="btn btn-sm btn-primary payBtn" value="<?php echo e($sale->id); ?>">Pay</button>
                     </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
          </table>
        </div>
      </div>
    </div>
</section>

<div class="modal fade text-start" id="myModal" tabindex="-1" aria-labelledby="myModalLabel1" aria-hidden="true">
    <div class="modal-dialog modal-md d-flex justify-content-center">
      <div class="modal-content" style="width: 90%;">
          <form id="addForm">
          <?php echo csrf_field(); ?>
              <div class="modal-header">
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <input type="hidden" class="order_id" name="order_id">
              <div class="modal-body">
                  <div class="form-group">
                    <label for=""><span class="error">*</span> Payment Amount </label>
                    <input type="text" name="due_payment" class="form-control">
                  </div>
                  <div class="form-group">
                    <label for=""><span class="error">*</span> Payment Date</label>
                    <input type="date" name="payment_date" class="form-control">
                  </div>
                  <div class="form-group">
                    <label for=""> Remarks</label>
                    <textarea name="remarks" class="form-control" cols="30" rows="5"></textarea>
                  </div>
              </div>
              <div class="modal-footer">
                  <button type="submit" class="btn btn-success" data-bs-dismiss="modal">Submit</button>
              </div>
          </form>
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>

$(document).ready(function(){
    $('#example').DataTable({
        scrollX: true,
        "pageLength": 10
    });
});

// view modal
$(document).on('click', '.payBtn', function() {
    $('#myModal').modal('show');
    var order_id = $(this).val();
    $('.order_id').val(order_id);
});

$("#addForm").submit(function() {
    event.preventDefault(); // prevent actual form submit
    var form = $(this);
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({
         type: "POST",
         url: '/sales/due',
         data: form.serialize(), // serializes form input
         success: function(data){
            location.reload();
         }
    });
});

</script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\Pos\resources\views/pos/salesDue.blade.php ENDPATH**/ ?>