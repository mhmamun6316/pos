
<?php /**PATH C:\Users\Dell\Desktop\Pos\resources\views/layouts/footer.blade.php ENDPATH**/ ?>