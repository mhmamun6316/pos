<h2>dd</h2>
<?php /**PATH C:\Users\Dell\Desktop\Pos\resources\views/product/sss.blade.php ENDPATH**/ ?>