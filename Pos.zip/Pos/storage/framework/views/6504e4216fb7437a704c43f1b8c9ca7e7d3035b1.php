<?php $__env->startSection('css'); ?>
<style>
    .error
    {
        color:red!important ;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

<h2>Add new expense</h2>

<form id="add-expense" action="<?php echo e(route('expenses.store')); ?>" enctype="multipart/form-data" method="POST">
    <?php echo csrf_field(); ?>
    <section id="product-info">
        <div class="row">
        <div class="col-md-12">
            <div class="card card-top">
            <div class="card-body">
                <div class="row">

                    <div class="col-xl-4 col-md-6 col-12">
                        <div class="mb-1">
                        <label class="form-label"><h4><span class="error">*</span> Outlet :</h4></label>
                        <select class="form-select" id="outlet_id" name="outlet_id">
                            <option selected disabled>Select a outlet name</option>
                            <?php $__currentLoopData = $outlets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outlet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($outlet->id); ?>"><?php echo e($outlet->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        </div>
                    </div>

                    <div class="col-xl-4 col-md-6 col-12">
                        <div class="mb-1">
                        <label class="form-label"><h4><span class="error">*</span> Expense Category :</h4></label>
                        <select class="form-select" id="expense_category_id" name="expense_category_id">
                            <option selected disabled>Select a expense category name</option>
                            <?php $__currentLoopData = $expenseCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expenseCategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($expenseCategori->id); ?>"><?php echo e($expenseCategori->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        </div>
                    </div>

                    <div class="col-xl-4 col-md-6 col-12">
                        <div class="mb-1">
                        <label class="form-label"><h4>Expense Name :</h4></label>
                        <input type="text" class="form-control" name="name" id="name" placeholder="Enter name">
                        </div>
                    </div>

                    <div class="col-xl-4 col-md-6 col-12">
                        <div class="mb-1">
                        <label class="form-label"><h4><span class="error">*</span> Expense Amount :</h4></label>
                        <input type="text" class="form-control" name="amount" id="amount" placeholder="Enter amount">
                        </div>
                    </div>

                    <div class="col-xl-8 col-md-6 col-12">
                        <div class="mb-1">
                        <label class="form-label"><h4>Remarks :</h4></label>
                        <input type="text" class="form-control" name="remark" id="remark" placeholder="Enter remarks">
                        </div>
                    </div>

                </div>
            </div>
            </div>
        </div>
        </div>
    </section>

    <div class="d-flex justify-content-center">
        <button type="submit" class="btn btn-success">Save Expense</button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/additional-methods.min.js"></script>
<script>

jQuery.extend(jQuery.validator.messages, {
    required: "This field is required",
    number: "This field should be a number",
    maxlength: jQuery.validator.format("This field must not be more than {0} characters"),
});

$('#add-expense').validate({
    rules: {
        'outlet_id':{
            required: true,
        },
        'expense_category_id':{
            required : true,
        },
        'amount':{
            required: true,
            number:true
        }
    }
});

</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\Pos\resources\views/expense/add_expense.blade.php ENDPATH**/ ?>