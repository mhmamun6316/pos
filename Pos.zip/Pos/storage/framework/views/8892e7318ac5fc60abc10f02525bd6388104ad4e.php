<?php $__env->startSection('main_content'); ?>


<section id="basic-datatable">
    <div class="row">
      <div class="col-12">
        <div class="card p-2 card-top">
          <div class="d-flex justify-content-between mb-1">
              <h4>All your products</h4>
          </div>
          <table id="example" class="table table-striped table-bordered" style="width:100%">
              <thead class="text-center">
                <tr>
                    <th scope="col">Sku</th>
                    <th scope="col">Product</th>
                    <th scope="col">Location</th>
                    <th scope="col">Unit Price</th>
                    <th scope="col">Current Stock</th>
                    <th scope="col">Current Stock Value <br> <small>(By purchase price)</small></th>
                    <th scope="col">Current Stock Value <br> <small>(By sale price)</small></th>
                    <th scope="col">Potential profit</th>
                    <th scope="col">Total Unit Sold</th>
                    <th scope="col">Total Unit Transferred</th>
                    <th scope="col">Total Unit Adjust</th>
                  </tr>
              </thead>
              <tbody id="tableBody" class="text-center">
                  <?php
                      $total_quantity = 0;
                      $total_by_purchase = 0;
                      $total_by_sell = 0;
                  ?>
                  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
                      $sell = $product->quantity * $product->selling_price;
                      $purchase = $product->quantity * $product->inc_purchase_price;
                      $total_quantity +=  $product->quantity;
                      $total_by_purchase += $purchase;
                      $total_by_sell += $sell;
                  ?>
                    <tr>
                        <td><?php echo e($product->sku); ?></td>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e(optional($product->outlet)->name); ?></td>
                        <td><?php echo e($product->selling_price); ?>TK</td>
                        <td><?php echo e($product->quantity); ?>PC</td>
                        <td><?php echo e($purchase); ?>TK</td>
                        <td><?php echo e($sell); ?>TK</td>
                        <td><?php echo e($sell - $purchase); ?>TK</td>
                        <td>0PC</td>
                        <td>0PC</td>
                        <td>0PC</td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              <tfoot class="text-center">
                    <tr>
                       <td colspan="4"><b>Total:</b></td>
                       <td><b><?php echo e($total_quantity); ?>PC</b></td>
                       <td><b><?php echo e($total_by_purchase); ?>TK</b></td>
                       <td><b><?php echo e($total_by_sell); ?>TK</b></td>
                       <td><b><?php echo e($total_by_sell - $total_by_purchase); ?>TK</b></td>
                       <td><b>0PC</b></td>
                       <td><b>0PC</b></td>
                       <td><b>0PC</b></td>
                    </tr>
              </tfoot>
          </table>
        </div>
      </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>

$(document).ready(function(){
    $('#example').DataTable({
        scrollX: true,
        scrollY: '200px',
        "pageLength": 10
    });
})

</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\Pos\resources\views/product/stock.blade.php ENDPATH**/ ?>