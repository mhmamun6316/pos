<?php $__env->startSection('css'); ?>
<style>
    .error
    {
        color:red!important ;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

<h1 class="header-title">
    <strong>Today Report</strong>
</h1>

<div class="row">

    <div class="col-md-3">
         <div class="card card-body bg-success">
              <h6 class="text-white text-uppercase">Sale Amount</h6>
              <p class="fs-18 fw-700 text-white">৳ <?php echo e($today_sell); ?></p>
         </div>
    </div>
    <div class="col-md-3">
         <div class="card card-body bg-danger">
              <h6 class="text-white text-uppercase">Purchase Cost</h6>
              <p class="fs-18 fw-700 text-white">৳ <?php echo e($purchase_cost->sums); ?></p>
         </div>
    </div>
    <div class="col-md-3">
         <div class="card card-body bg-dark">
              <h6 class="text-white text-uppercase">Expense Amount</h6>
              <p class="fs-18 fw-700 text-white">৳ <?php echo e($today_expenses); ?></p>
         </div>
    </div>
    <div class="col-md-3">
         <div class="card card-body bg-primary">
              <h6 class="text-white text-uppercase">Sell Profit</h6>
              <p class="fs-18 fw-700 text-white">৳ <?php echo e($today_profit); ?>

              </p>
         </div>
    </div>

</div>

<div class="row">

    <div class="col-lg-6 col-md-6 col-sm-12">
        <div class="card">
             <div class="card-header bg-primary d-flex justify-between">
                <h5 class="card-title text-white"><strong>Today Sell Products</strong></h5>
                <a class="btn btn-success" target="blank" href="<?php echo e(route('today.sell.product')); ?>">PRINT</a>
             </div>

             <div class="card-body">
                <table class="example table table-striped table-bordered" style="width:100%">
                    <thead class="text-center">
                      <tr>
                          <th>Outlet</th>
                          <th>Product Name</th>
                          <th>Quantity</th>
                          <th>Price</th>
                        </tr>
                    </thead>
                    <tbody id="tableBody" class="text-center">
                        <?php $__currentLoopData = $today_sell_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->outlet_name); ?></td>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->qty); ?></td>
                                <td><?php echo e($item->selling_price); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
             </div>
        </div>
    </div>

    <div class="col-lg-6 col-md-6 col-sm-12">
        <div class="card">
            <div class="card-header bg-danger d-flex justify-between">
                <h5 class="card-title text-white"><strong>Today Expenses</strong></h5>
                <a class="btn btn-success" target="blank" href="<?php echo e(route('today.expenses')); ?>">PRINT</a>
           </div>

             <div class="card-body">
                <table class="example table table-striped table-bordered" style="width:100%">
                    <thead class="text-center">
                      <tr>
                          <th>Outlet</th>
                          <th>Expense</th>
                          <th>Amount</th>
                        </tr>
                    </thead>
                    <tbody id="tableBody" class="text-center">
                        <?php $__currentLoopData = $today_expenses_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->outlet_name); ?></td>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->amount); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
             </div>
        </div>
    </div>

    <div class="col-lg-6 col-md-6 col-sm-12">
        <div class="card">
             <div class="card-header bg-success">
                  <h5 class="card-title text-white"><strong>Today Customer Pays</strong></h5>
             </div>

             <div class="card-body">
                <table class="example table table-striped table-bordered" style="width:100%">
                    <thead class="text-center">
                      <tr>
                          <th>Customer Name</th>
                          <th>Amount</th>
                          <th>Note</th>
                        </tr>
                    </thead>
                    <tbody id="tableBody" class="text-center">
                        <?php $__currentLoopData = $today_due_pays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->name); ?></td>
                                <td>323</td>
                                <td><?php echo e($item->note); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
             </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
           $(document).ready(function(){
                $('.example').DataTable({
                    scrollX: true,
                    "pageLength": 10
                });
            });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\Pos\resources\views/reports/today_report.blade.php ENDPATH**/ ?>